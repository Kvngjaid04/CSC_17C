/* 
 * File:   main.cpp
 * Author: Ireoluwa Dairo
 * Created on March 4, 2025, 5:49 PM
 */

#include <cstdlib>
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Mathematical, Scientific, Conversions

//Higher Dimensions go here. No Variables

//Function Prototypes

//Execution Begins here

int main(int argc, char** argv) {
    //Setting the random number seed

    //Declaring Variables

    //Initialize Variables

    //Processing/Mapping Inputs to Outputs

    //Displaying Input/Output Information
    cout << "hello world";
    //Exiting stage left/right
    return 0;
}
